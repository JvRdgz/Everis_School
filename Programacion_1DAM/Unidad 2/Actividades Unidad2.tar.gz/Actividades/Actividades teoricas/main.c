#include <stdio.h>

void main()
{
	float f = 123.456;
	
	printf("%f\n", f);
	printf("%.4f\n", f);
	printf("%.3f\n", f);
	printf("%10.5f\n", f);
	printf("%6.0f\n", f);
}
