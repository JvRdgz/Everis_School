/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package claseEnvoltorio;

/**
 *
 * @author Javier
 */
public class Main {
    
    public static void main(String[]args) {
        System.out.println("\n\tTIPO CHAR\n");
        System.out.println("Valor minimo char: " + (int)Character.MIN_VALUE);
        System.out.println("Valor maximo char: " + (int)Character.MAX_VALUE);
        System.out.println("\n\tTIPO INTEGER\n");
        System.out.println("Valor minimo int: " + Integer.MIN_VALUE);
        System.out.println("Valor maximo int: " + Integer.MAX_VALUE);
        System.out.println("\n\tTIPO SHORT\n");
        System.out.println("Valor minimo short: " + Short.MIN_VALUE);
        System.out.println("Valor maximo short: " + Short.MAX_VALUE);
        System.out.println("\n\tTIPO LONG\n");
        System.out.println("Valor minimo long: " + Long.MIN_VALUE);
        System.out.println("Valor maximo long: " + Long.MAX_VALUE);
        System.out.println("\n\tTIPO FLOAT\n");
        System.out.println("Valor minimo float: " + Float.MIN_VALUE);
        System.out.println("Valor maximo float: " + Float.MAX_VALUE);
        System.out.println("\n\tTIPO DOUBLE\n");
        System.out.println("Valor minimo double: " + Double.MIN_VALUE);
        System.out.println("Valor maximo double: " + Double.MAX_VALUE + "\n");
    }
}
