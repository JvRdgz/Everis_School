#include <stdio.h>
#include <stdlib.h>

void main(void)
{
	int num;
	printf("Introduce un numero entero: \n");
	scanf("%d", &num);
	printf("%d\n", num*2);
}
